"""HAPAutoSaver settings dialog"""

from pathlib import Path

from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDialog

_ui_class, _ = uic.loadUiType(Path(__file__).resolve().parent / "ui_autosave_dialog_base.ui")


class HAPAutoSaverDialog(_ui_class, QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
