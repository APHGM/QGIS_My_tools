"""HAPAutoSaver — auto-save project and edited layers (QGIS 4 / PyQt6)"""

import os
from pathlib import Path

from qgis.core import QgsProject
from qgis.PyQt.QtCore import QCoreApplication, QFileInfo, QSettings, QTimer, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.utils import plugins

from .hapautosaver_dialog import HAPAutoSaverDialog

_PLUGIN = "HAPAutoSaver"
_SETTINGS_PREFIX = "HAPAutoSaver"


class HAPAutoSaver:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        self.iface      = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions    = []
        self.dlg        = None
        self.cron       = None

        locale = QSettings().value("locale/userLocale")[0:2]
        locale_path = os.path.join(self.plugin_dir, "i18n", f"{_PLUGIN}_{locale}.qm")
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

    # ── GUI lifecycle ────────────────────────────────────────────────────────

    def initGui(self):
        self.dlg = HAPAutoSaverDialog(self.iface.mainWindow())

        icon = QIcon(str(Path(__file__).resolve().parent / "icon.png"))
        self.action = QAction(icon, "HAPAutoSaver — auto-save project", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(f"&{_PLUGIN}", self.action)
        self.actions.append(self.action)

        self.cron = QTimer()
        self.cron.timeout.connect(self._cron_event)

        self._init_from_settings()

        self.dlg.enableAutoSave.clicked.connect(self._on_enable_toggled)
        self.dlg.buttonOkNo.accepted.connect(self._on_accepted)
        self.dlg.buttonOkNo.rejected.connect(self.dlg.hide)
        self.dlg.enableSaveLayersBuffer.hide()

    def unload(self):
        if self.cron:
            self.cron.stop()
        for action in self.actions:
            self.iface.removePluginMenu(f"&{_PLUGIN}", action)
            self.iface.removeToolBarIcon(action)

    def run(self):
        self.dlg.show()
        self.dlg.raise_()

    # ── settings initialisation ──────────────────────────────────────────────

    def _init_from_settings(self):
        s = QSettings()
        enabled = s.value(f"{_SETTINGS_PREFIX}/enabled", "undef")

        if enabled == "undef":
            # First run — write defaults
            s.setValue(f"{_SETTINGS_PREFIX}/enabled",              "false")
            s.setValue(f"{_SETTINGS_PREFIX}/alternateBak",         "true")
            s.setValue(f"{_SETTINGS_PREFIX}/saveLayerInEditMode",  "false")
            s.setValue(f"{_SETTINGS_PREFIX}/saveLayerBuffer",      "false")
            s.setValue(f"{_SETTINGS_PREFIX}/interval",             "10")
            self._apply_ui(enabled=False, interval="10", alternate=True,
                           save_layers=False, save_buffer=False)

        elif enabled == "true":
            interval = s.value(f"{_SETTINGS_PREFIX}/interval", "10")
            self._apply_ui(
                enabled=True,
                interval=interval,
                alternate=s.value(f"{_SETTINGS_PREFIX}/alternateBak", "true") == "true",
                save_layers=s.value(f"{_SETTINGS_PREFIX}/saveLayerInEditMode", "false") == "true",
                save_buffer=s.value(f"{_SETTINGS_PREFIX}/saveLayerBuffer", "false") == "true",
            )
            self._start(interval)

        else:  # "false"
            interval = s.value(f"{_SETTINGS_PREFIX}/interval", "10")
            self._apply_ui(
                enabled=False,
                interval=interval,
                alternate=s.value(f"{_SETTINGS_PREFIX}/alternateBak", "true") == "true",
                save_layers=s.value(f"{_SETTINGS_PREFIX}/saveLayerInEditMode", "false") == "true",
                save_buffer=s.value(f"{_SETTINGS_PREFIX}/saveLayerBuffer", "false") == "true",
            )

    def _apply_ui(self, enabled, interval, alternate, save_layers, save_buffer):
        d = self.dlg
        d.enableAutoSave.setChecked(enabled)
        d.interval.setText(str(interval))
        d.enableAlternate.setChecked(alternate)
        d.enableSaveLayers.setChecked(save_layers)
        d.enableSaveLayersBuffer.setChecked(save_buffer)

        d.enableAlternate.setEnabled(enabled)
        d.interval.setEnabled(enabled)
        d.intervalLabel.setEnabled(enabled)
        d.enableSaveLayers.setEnabled(enabled)
        d.enableSaveLayersBuffer.setEnabled(
            enabled and save_layers and "layerVersion" in plugins
        )

    # ── UI slots ─────────────────────────────────────────────────────────────

    def _on_enable_toggled(self):
        enabled = self.dlg.enableAutoSave.isChecked()
        self.dlg.enableAlternate.setEnabled(enabled)
        self.dlg.interval.setEnabled(enabled)
        self.dlg.intervalLabel.setEnabled(enabled)
        self.dlg.enableSaveLayers.setEnabled(enabled)
        self.dlg.enableSaveLayersBuffer.setEnabled(
            enabled and "layerVersion" in plugins
        )

    def _on_accepted(self):
        try:
            minutes = int(self.dlg.interval.text())
        except ValueError:
            QMessageBox.warning(self.dlg, _PLUGIN, "Interval must be a whole number.")
            return

        s = QSettings()
        enabled     = self.dlg.enableAutoSave.isChecked()
        alternate   = self.dlg.enableAlternate.isChecked()
        save_layers = self.dlg.enableSaveLayers.isChecked()
        save_buffer = self.dlg.enableSaveLayersBuffer.isChecked()

        s.setValue(f"{_SETTINGS_PREFIX}/enabled",             "true" if enabled else "false")
        s.setValue(f"{_SETTINGS_PREFIX}/alternateBak",        "true" if alternate else "false")
        s.setValue(f"{_SETTINGS_PREFIX}/saveLayerInEditMode", "true" if save_layers else "false")
        s.setValue(f"{_SETTINGS_PREFIX}/saveLayerBuffer",     "true" if save_buffer else "false")
        s.setValue(f"{_SETTINGS_PREFIX}/interval",            str(minutes))

        if enabled:
            self._start(str(minutes))
        else:
            self._stop()

        self.dlg.hide()

    # ── timer ────────────────────────────────────────────────────────────────

    def _start(self, interval_str):
        try:
            ms = int(interval_str) * 60_000
        except ValueError:
            ms = 600_000  # fallback 10 min
        self.cron.start(ms)

    def _stop(self):
        self.cron.stop()

    def _cron_event(self):
        if self.dlg.enableSaveLayers.isChecked():
            self._save_layers_in_edit_mode()
        self._save_current_project()

    # ── save actions ─────────────────────────────────────────────────────────

    def _save_layers_in_edit_mode(self):
        if "layerVersion" in plugins and self.dlg.enableSaveLayersBuffer.isChecked():
            lv  = plugins["layerVersion"]
            dom = lv.editingStateSaver.getEditsXMLDefinition()
            if dom:
                out = os.path.join(
                    QgsProject.instance().readPath("./"), "autosave.qlv"
                )
                with open(out, "w") as f:
                    f.write(dom.toString())
        else:
            for layer in self.iface.mapCanvas().layers():
                if layer.isEditable() and layer.isModified():
                    layer.commitChanges()
                    layer.startEditing()
                    self.iface.messageBar().pushSuccess(
                        _PLUGIN, f"Auto-saved layer: {layer.name()}"
                    )

    def _save_current_project(self):
        orig = QgsProject.instance().fileName()
        if not orig or not QgsProject.instance().isDirty():
            return

        if self.dlg.enableAlternate.isChecked():
            base, ext = os.path.splitext(orig)
            bak_file    = orig + ".bak"
            write_to    = orig          # write to original path first, then rename
            msg         = f"Project auto-saved to: {bak_file}"
        else:
            bak_file = None
            write_to = orig
            msg      = "Project auto-saved"

        os.environ["QGIS_PLUGIN_AUTO_SAVER"] = "True"
        try:
            if bak_file:
                # Write to a temp name then rename to .bak
                tmp = orig + ".autosave_tmp"
                QgsProject.instance().setFileName(tmp)
                QgsProject.instance().write()
                QgsProject.instance().setFileName(orig)
                try:
                    os.remove(bak_file)
                except OSError:
                    pass
                os.rename(tmp, bak_file)
            else:
                QgsProject.instance().write()
        finally:
            os.environ.pop("QGIS_PLUGIN_AUTO_SAVER", None)

        self.iface.messageBar().pushSuccess(_PLUGIN, msg)
