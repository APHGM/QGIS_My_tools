from .hapautosaver import HAPAutoSaver


def classFactory(iface):
    return HAPAutoSaver(iface)
