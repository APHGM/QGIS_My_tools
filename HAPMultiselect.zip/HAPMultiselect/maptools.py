"""HAP Multi-layer Selection Map Tools — QGIS 4 / PyQt6"""

import math

from qgis.core import (
    Qgis,
    QgsGeometry,
    QgsPointXY,
    QgsRectangle,
    QgsVectorLayer,
)
from qgis.gui import QgsDoubleSpinBox, QgsMapTool, QgsMapToolIdentify, QgsRubberBand
from qgis.PyQt.QtCore import QEvent, QPoint, QSettings, Qt, pyqtSignal
from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QSizePolicy, QWidget
from qgis.utils import iface

from .icon_utils import cursor_from_image, icon_path
from .ignore_scale import disable_scale_based_visibility
from .utils import update_status_message, vector_layers

_POLYGON = Qgis.GeometryType.Polygon
_ADD    = Qgis.SelectBehavior.AddToSelection
_REMOVE = Qgis.SelectBehavior.RemoveFromSelection


def has_moved(pos1: QPoint, pos2: QPoint, pixel_threshold=10) -> bool:
    return math.hypot(pos1.x() - pos2.x(), pos1.y() - pos2.y()) > pixel_threshold


class HAPSelectTool(QgsMapToolIdentify):
    """Base class for HAP multi-layer selection tools"""

    def __init__(self, canvas):
        super().__init__(canvas)
        canvas.mapToolSet.connect(self._on_tool_set)
        self.status_message = ""
        self.rubber  = QgsRubberBand(canvas, _POLYGON)
        self.rubber2 = QgsRubberBand(canvas, _POLYGON)

    def flags(self):
        return QgsMapTool.Flags()

    def _on_tool_set(self, new_tool, old_tool):
        if new_tool == self:
            iface.statusBarIface().showMessage(self.status_message)
        elif old_tool == self:
            self.reset()
            iface.statusBarIface().clearMessage()

    def refresh_color(self):
        stroke = self.canvas().selectionColor().darker(150)
        fill   = self.canvas().selectionColor()
        fill.setAlphaF(0.2)
        for rb in (self.rubber, self.rubber2):
            rb.setColor(fill)
            rb.setStrokeColor(stroke)
            rb.setWidth(1)
        self.rubber2.setLineStyle(Qt.PenStyle.DotLine)

    def reset(self):
        self.rubber.reset(_POLYGON)
        self.rubber2.reset(_POLYGON)

    def __del__(self):
        self.reset()

    def select(self, geom, modifiers):
        if QSettings().value("plugins/HAPMultiselect/ignore_scale", False, bool):
            with disable_scale_based_visibility():
                self._select(geom, modifiers)
        else:
            self._select(geom, modifiers)

    def _select(self, geom, modifiers):
        layers = vector_layers(True) if isinstance(geom, QgsPointXY) else vector_layers()
        if not layers:
            return

        ctrl  = bool(modifiers & Qt.KeyboardModifier.ControlModifier)
        shift = bool(modifiers & Qt.KeyboardModifier.ShiftModifier)
        selected_dict = {layer: [layer.selectedFeatureIds(), []] for layer in layers}

        if isinstance(geom, QgsPointXY):
            results = self.identify(
                QgsGeometry.fromPointXY(geom),
                QgsMapToolIdentify.TopDownStopAtFirst,
                layers,
                QgsMapToolIdentify.VectorLayer,
            )
            was_selected = False
            if results:
                res = results[-1]
                was_selected = res.mFeature.id() in selected_dict[res.mLayer][0]
                selected_dict[res.mLayer][1].append(res.mFeature.id())
            for layer, (_, new) in selected_dict.items():
                if shift or ctrl:
                    layer.selectByIds(new, _REMOVE if was_selected else _ADD)
                else:
                    layer.selectByIds(new)
        else:
            results = self.identify(
                geom,
                QgsMapToolIdentify.TopDownAll,
                layers,
                QgsMapToolIdentify.VectorLayer,
            )
            for res in results:
                selected_dict[res.mLayer][1].append(res.mFeature.id())
            for layer, (_, new) in selected_dict.items():
                if shift:
                    layer.selectByIds(new, _ADD)
                elif ctrl:
                    layer.selectByIds(new, _REMOVE)
                else:
                    layer.selectByIds(new)

        active_layers = [l for l in selected_dict if l.selectedFeatureCount() > 0]
        if (
            active_layers
            and iface.activeLayer() not in active_layers
            and QSettings().value("plugins/HAPMultiselect/set_active_layer", True, bool)
        ):
            iface.setActiveLayer(active_layers[0])

        update_status_message()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.reset()


class HAPSelectRectTool(HAPSelectTool):
    """Rectangle / click selection across all layers"""

    def __init__(self, canvas):
        super().__init__(canvas)
        self.setCursor(cursor_from_image(icon_path("selectRectangleCursor.svg")))
        self.ref_point = None
        self.ref_pos   = None

    def canvasPressEvent(self, event):
        self.ref_pos   = event.pos()
        self.ref_point = self.toMapCoordinates(event.pos())
        self.refresh_color()

    def canvasMoveEvent(self, event):
        if self.ref_point:
            self.rubber.reset(_POLYGON)
            p = self.toMapCoordinates(event.pos())
            rect = QgsRectangle(
                min(p.x(), self.ref_point.x()), min(p.y(), self.ref_point.y()),
                max(p.x(), self.ref_point.x()), max(p.y(), self.ref_point.y()),
            )
            self.rubber.addGeometry(QgsGeometry.fromRect(rect), None)

    def canvasReleaseEvent(self, event):
        if not self.canvas().currentLayer():
            self.reset()
            return
        if event.button() == Qt.MouseButton.LeftButton:
            p = self.toMapCoordinates(event.pos())
            if self.ref_point and has_moved(self.ref_pos, event.pos()):
                self.select(self.rubber.asGeometry(), event.modifiers())
            else:
                self.select(p, event.modifiers())
            self.reset()

    def reset(self):
        super().reset()
        self.ref_point = None
        self.ref_pos   = None


class HAPSelectPolygonTool(HAPSelectTool):
    """Polygon selection across all layers"""

    def __init__(self, canvas):
        super().__init__(canvas)
        self.setCursor(cursor_from_image(icon_path("selectPolygonCursor.svg")))
        self.pressed = False

    def canvasPressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if self.rubber.numberOfVertices() == 0:
                self.refresh_color()
            p = self.toMapCoordinates(event.pos())
            self.rubber.addPoint(p)
            self.rubber2.reset(_POLYGON)
            for i in range(self.rubber.numberOfVertices()):
                self.rubber2.addPoint(self.rubber.getPoint(0, i))
            self.rubber2.addPoint(p)
            self.pressed = True
        elif event.button() == Qt.MouseButton.RightButton:
            if self.rubber.numberOfVertices() > 2:
                self.select(self.rubber.asGeometry(), event.modifiers())
            self.reset()

    def canvasReleaseEvent(self, event):
        self.pressed = False

    def canvasMoveEvent(self, event):
        p = self.toMapCoordinates(event.pos())
        if self.pressed:
            self.rubber.addPoint(p)
            self.rubber2.addPoint(p)
        else:
            self.rubber2.movePoint(self.rubber2.numberOfVertices() - 1, p)


class DistanceWidget(QWidget):
    distanceChanged         = pyqtSignal(float)  # noqa: N815
    distanceEditingFinished = pyqtSignal(int)    # noqa: N815
    distanceEditingCanceled = pyqtSignal()       # noqa: N815

    def __init__(self, label, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
        if label:
            lbl = QLabel(label, self)
            lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(lbl)
        self.spinbox = QgsDoubleSpinBox(self)
        self.spinbox.setSingleStep(1)
        self.spinbox.setMinimum(0)
        self.spinbox.setMaximum(1_000_000_000)
        self.spinbox.setDecimals(6)
        self.spinbox.setShowClearButton(False)
        self.spinbox.setSizePolicy(
            QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Preferred
        )
        layout.addWidget(self.spinbox)
        self.spinbox.installEventFilter(self)
        self.spinbox.valueChanged.connect(self.distanceChanged.emit)
        self.setFocusProxy(self.spinbox)

    def set_distance(self, d):
        self.spinbox.setValue(d)
        self.spinbox.selectAll()

    def distance(self):
        return self.spinbox.value()

    def eventFilter(self, obj, event):
        if obj is self.spinbox and event.type() == QEvent.Type.KeyPress:
            if event.key() == Qt.Key.Key_Escape:
                self.distanceEditingCanceled.emit()
                return True
            if event.key() in (Qt.Key.Key_Enter, Qt.Key.Key_Return):
                self.distanceEditingFinished.emit(int(event.modifiers()))
                return True
        return False


class HAPSelectRadiusTool(HAPSelectTool):
    """Circle / radius selection across all layers"""

    def __init__(self, canvas):
        super().__init__(canvas)
        self.setCursor(cursor_from_image(icon_path("selectRadiusCursor.svg")))
        self.center_point    = None
        self.distance_widget = None

    def canvasMoveEvent(self, event):
        if self.center_point:
            edge = self.toMapCoordinates(event.pos())
            self.distance_widget.set_distance(
                math.sqrt(self.center_point.sqrDist(edge))
            )

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.reset()
            return
        if not self.canvas().currentLayer():
            self.reset()
            return
        if not self.center_point:
            self.center_point = self.toMapCoordinates(event.pos())
            self.refresh_color()
            self._create_distance_widget()
            return
        self._validate(event.modifiers())

    def _validate(self, modifiers):
        self.select(self.rubber.asGeometry(), modifiers)
        self.reset()

    def reset(self):
        super().reset()
        self.center_point = None
        self._delete_distance_widget()

    def _update_rubber(self, radius):
        self.rubber.reset(_POLYGON)
        for i in range(80):
            theta = math.radians(i * 360 / 80)
            self.rubber.addPoint(
                QgsPointXY(
                    self.center_point.x() + radius * math.cos(theta),
                    self.center_point.y() + radius * math.sin(theta),
                ),
                False,
            )
        self.rubber.closePoints(True)

    def _create_distance_widget(self):
        self._delete_distance_widget()
        self.distance_widget = DistanceWidget(self.tr("Selection radius"))
        self.distance_widget.distanceChanged.connect(self._update_rubber)
        self.distance_widget.distanceEditingFinished.connect(self._validate)
        self.distance_widget.distanceEditingCanceled.connect(self.reset)
        iface.addUserInputWidget(self.distance_widget)
        self.distance_widget.setFocus(Qt.FocusReason.TabFocusReason)

    def _delete_distance_widget(self):
        if self.distance_widget:
            self.distance_widget.deleteLater()
            self.distance_widget = None


class HAPSelectFreehandTool(HAPSelectTool):
    """Freehand selection across all layers"""

    def __init__(self, canvas):
        super().__init__(canvas)
        self.setCursor(cursor_from_image(icon_path("selectFreehandCursor.svg")))
        self.ref_point = None

    def canvasMoveEvent(self, event):
        if self.ref_point:
            self.rubber.addPoint(self.toMapCoordinates(event.pos()))

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.reset()
            return
        if not self.canvas().currentLayer():
            self.reset()
            return
        if not self.ref_point:
            self.ref_point = self.toMapCoordinates(event.pos())
            self.refresh_color()
            return
        self.select(self.rubber.asGeometry(), event.modifiers())
        self.reset()

    def reset(self):
        super().reset()
        self.ref_point = None
