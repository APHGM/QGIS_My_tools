from .hapmultiselect import HAPMultiselect


def classFactory(iface):
    return HAPMultiselect(iface)
