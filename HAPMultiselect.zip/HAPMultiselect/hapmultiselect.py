"""HAPMultiselect — Multi-layer selection tools for QGIS 4"""

import configparser
import os
from functools import partial

from qgis.core import Qgis, QgsProject, QgsProjectVersion, QgsVectorLayer
from qgis.gui import QgsGui
from qgis.PyQt.QtCore import QCoreApplication, QObject, QSettings, QTranslator
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QToolBar, QToolButton, QWidget

from .icon_utils import create_icon, expression_select_icon, icon_path, invert_selection_icon, select_all_icon
from .maptools import (
    HAPSelectFreehandTool,
    HAPSelectPolygonTool,
    HAPSelectRadiusTool,
    HAPSelectRectTool,
)
from .utils import update_status_message, vector_layers
from .multiselectionexpressionbuilder import MultiLayerSelectionExpressionBuilder
from .settingsdialog import SettingsDialog

_PLUGIN_NAME = "HAPMultiselect"


class HAPMultiselect:
    """QGIS Plugin Implementation for HAPMultiselect"""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        locale = QSettings().value("locale/userLocale")[0:2]
        locale_path = os.path.join(self.plugin_dir, "i18n", f"{_PLUGIN_NAME}_{locale}.qm")
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.settings = QSettings()
        self.settings.beginGroup(f"plugins/{_PLUGIN_NAME}")

        self.action_container = QObject()
        self.action_container.setObjectName(_PLUGIN_NAME)

    def tr(self, message):
        return QCoreApplication.translate(_PLUGIN_NAME, message)

    def initGui(self):
        self.settings_dialog = SettingsDialog(self.settings, self.iface.mainWindow())
        self.expression_dialog = None

        try:
            QgsProject.instance().selectionColorChanged.connect(self.on_color_changed)
            QgsProject.instance().selectionColorChanged.connect(
                self.settings_dialog.on_project_color_changed
            )
        except AttributeError:
            self.settings_dialog.colorChanged.connect(self.on_color_changed)
            QgsProject.instance().readProject.connect(
                self.settings_dialog.on_project_color_changed
            )

        self.settings_dialog.settingsChanged.connect(self.on_settings_changed)

        self.toolbar = QToolBar(_PLUGIN_NAME, self.iface.mainWindow())
        self.toolbar.setObjectName("HAPMultiselectToolbar")

        self.about_action = QAction(
            QIcon(icon_path("about.svg")),
            self.tr("About HAPMultiselect"),
            parent=self.action_container,
        )
        self.about_action.triggered.connect(self.show_about)

        self.settings_action = QAction(
            QIcon(":/images/themes/default/console/iconSettingsConsole.svg"),
            self.tr("HAPMultiselect Settings"),
            parent=self.action_container,
        )
        self.settings_action.setObjectName("actionHAPMultiselectSettings")
        self.settings_action.triggered.connect(self.show_settings)

        self.plugin_menu = self.iface.pluginMenu().addMenu(
            QIcon(icon_path("icon.svg")), _PLUGIN_NAME
        )
        self.plugin_menu.addAction(self.about_action)
        self.plugin_menu.addAction(self.settings_action)

        self.selection_tool_button = QToolButton(self.toolbar)
        self.selection_tool_button.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.selection_tool_button.setObjectName("hapSelectionToolButton")

        self.advanced_selection_tool_button = QToolButton(self.toolbar)
        self.advanced_selection_tool_button.setPopupMode(
            QToolButton.ToolButtonPopupMode.MenuButtonPopup
        )
        self.advanced_selection_tool_button.setObjectName("hapAdvancedSelectionToolButton")

        self.select_rect_tool     = HAPSelectRectTool(self.iface.mapCanvas())
        self.select_polygon_tool  = HAPSelectPolygonTool(self.iface.mapCanvas())
        self.select_freehand_tool = HAPSelectFreehandTool(self.iface.mapCanvas())
        self.select_radius_tool   = HAPSelectRadiusTool(self.iface.mapCanvas())

        self.actions_settings = [
            _SelectAction(
                text=self.tr("Select Features"),
                tooltip=self.tr("<b>Select Features by area or single click</b>"),
                icon=icon_path("selectRectangle.svg"),
                objectname="actionHAPSelectByRectangle",
                tool=self.select_rect_tool,
            ),
            _SelectAction(
                text=self.tr("Select Features by Polygon"),
                icon=icon_path("selectPolygon.svg"),
                objectname="actionHAPSelectByPolygon",
                tool=self.select_polygon_tool,
            ),
            _SelectAction(
                text=self.tr("Select Features by Freehand"),
                icon=icon_path("selectFreehand.svg"),
                objectname="actionHAPSelectByFreehand",
                tool=self.select_freehand_tool,
            ),
            _SelectAction(
                text=self.tr("Select Features by Radius"),
                icon=icon_path("selectRadius.svg"),
                objectname="actionHAPSelectByRadius",
                tool=self.select_radius_tool,
            ),
        ]

        def on_select_tool(tool, action):
            self.selection_tool_button.setDefaultAction(action)
            if self.embedded_selection_tool_button:
                self.embedded_selection_tool_button.setDefaultAction(action)
            self.iface.mapCanvas().setMapTool(tool)

        self.select_actions = []

        disambiguator = ""
        if not QgsProjectVersion(Qgis.version()) >= QgsProjectVersion("3.31"):
            disambiguator = " "

        for select_action in self.actions_settings:
            action = QAction(select_action.text + disambiguator, parent=self.action_container)
            action.setToolTip(select_action.tooltip)
            action.setObjectName(select_action.objectname)
            action.setCheckable(True)
            select_action.tool.setAction(action)
            action.triggered.connect(partial(on_select_tool, select_action.tool, action))
            self.selection_tool_button.addAction(action)
            if not self.selection_tool_button.defaultAction():
                self.selection_tool_button.setDefaultAction(action)
            self.select_actions.append(action)

        self.toolbar.addWidget(self.selection_tool_button)

        self.select_all_action = QAction(
            self.tr("Select All Features from All Layers"), parent=self.action_container
        )
        self.select_all_action.setToolTip("<b>{}</b>".format(self.select_all_action.text()))
        self.select_all_action.setObjectName("actionHAPSelectAll")
        self.select_all_action.triggered.connect(self.select_all)
        self.advanced_selection_tool_button.addAction(self.select_all_action)
        self.advanced_selection_tool_button.setDefaultAction(self.select_all_action)

        self.invert_all_action = QAction(
            self.tr("Invert Selection for All Layers"), parent=self.action_container
        )
        self.invert_all_action.setToolTip("<b>{}</b>".format(self.invert_all_action.text()))
        self.invert_all_action.setObjectName("actionHAPSelectInvert")
        self.invert_all_action.triggered.connect(self.invert_all)
        self.advanced_selection_tool_button.addAction(self.invert_all_action)

        self.select_by_expr_action = QAction(
            QIcon(":/images/themes/default/mIconExpressionSelect.svg"),
            self.tr("Select Features by Expression...") + disambiguator,
            parent=self.action_container,
        )
        self.select_by_expr_action.setToolTip(
            "<b>{}</b>".format(self.select_by_expr_action.text())
        )
        self.select_by_expr_action.setObjectName("actionHAPSelectExpr")
        self.select_by_expr_action.triggered.connect(self.select_by_expression)
        self.advanced_selection_tool_button.addAction(self.select_by_expr_action)

        self.toolbar.addWidget(self.advanced_selection_tool_button)

        self.deselect_all_action = QAction(
            self.tr("Deselect Features from All Layers") + disambiguator,
            parent=self.action_container,
        )
        self.deselect_all_action.setToolTip(
            "<b>{}</b>".format(self.deselect_all_action.text())
        )
        self.deselect_all_action.setObjectName("actionHAPDeselectAll")
        self.deselect_all_action.triggered.connect(self.deselect_all)
        self.toolbar.addAction(self.deselect_all_action)

        self.toolbar.addAction(self.settings_action)
        self.iface.mainWindow().addToolBar(self.toolbar)

        self.embedded_selection_tool_button_action = None
        self.embedded_selection_tool_button        = None
        self.embedded_advanced_tool_button_action  = None
        self.embedded_advanced_tool_button         = None

        self.on_color_changed()
        self.on_settings_changed()

        QgsGui.shortcutsManager().registerAllChildren(self.action_container)

    def unload(self):
        self.settings_dialog.deleteLater()
        self.iface.pluginMenu().removeAction(self.plugin_menu.menuAction())

        self.select_freehand_tool.deleteLater()
        self.select_polygon_tool.deleteLater()
        self.select_radius_tool.deleteLater()
        self.select_rect_tool.deleteLater()

        self.iface.mainWindow().removeToolBar(self.toolbar)
        self.toolbar.deleteLater()

        self.replace_default_action(False)

        try:
            QgsProject.instance().selectionColorChanged.disconnect(self.on_color_changed)
            QgsProject.instance().selectionColorChanged.disconnect(
                self.settings_dialog.on_project_color_changed
            )
        except AttributeError:
            pass

        for action in self.action_container.children():
            action.deleteLater()

    def show_about(self):
        bogus = QWidget(self.iface.mainWindow())
        bogus.setWindowIcon(QIcon(icon_path("icon.svg")))

        cfg = configparser.ConfigParser()
        cfg.read(os.path.join(self.plugin_dir, "metadata.txt"))
        version = cfg.get("general", "version")

        QMessageBox.about(
            bogus,
            self.tr("About HAPMultiselect"),
            f"<b>HAPMultiselect</b><br><br>"
            f"<b>Version</b> {version}<br><br>"
            "Multi-layer selection tools for QGIS 4",
        )
        bogus.deleteLater()

    def show_settings(self):
        geometry = self.settings_dialog.geometry()
        if geometry.y() == 0:
            self.settings_dialog.show()
            self.settings_dialog.raise_()
            self.settings_dialog.setGeometry(self.settings_dialog.geometry())
            return
        self.settings_dialog.show()
        self.settings_dialog.raise_()

    def on_color_changed(self):
        color = self.iface.mapCanvas().selectionColor()
        color = QColor.fromHsv(
            int(color.hue()),
            int(color.saturation() * 0.9),
            int(color.value() * 0.95),
            int(color.alpha()),
        )
        for i in range(len(self.select_actions)):
            self.select_actions[i].setIcon(
                create_icon(self.actions_settings[i].icon, color)
            )
        self.deselect_all_action.setIcon(create_icon(icon_path("deselectAll.svg"), color))
        self.select_all_action.setIcon(select_all_icon(color))
        self.invert_all_action.setIcon(invert_selection_icon(color))
        self.select_by_expr_action.setIcon(expression_select_icon(color))

    def on_settings_changed(self):
        if self.settings.value("show_settings", True, bool):
            self.toolbar.addAction(self.settings_action)
        else:
            self.toolbar.removeAction(self.settings_action)
        self.replace_default_action(self.settings.value("replace_actions", False, bool))

    def deselect_all(self):
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                layer.removeSelection()
        update_status_message()

    def select_all(self):
        for layer in vector_layers():
            layer.selectAll()
        self.advanced_selection_tool_button.setDefaultAction(self.select_all_action)
        if self.embedded_advanced_tool_button:
            self.embedded_advanced_tool_button.setDefaultAction(self.select_all_action)
        update_status_message()

    def invert_all(self):
        for layer in vector_layers():
            layer.invertSelection()
        self.advanced_selection_tool_button.setDefaultAction(self.invert_all_action)
        if self.embedded_advanced_tool_button:
            self.embedded_advanced_tool_button.setDefaultAction(self.invert_all_action)
        update_status_message()

    def select_by_expression(self):
        if self.expression_dialog:
            self.expression_dialog.deleteLater()
        self.expression_dialog = MultiLayerSelectionExpressionBuilder()
        self.expression_dialog.show()
        self.advanced_selection_tool_button.setDefaultAction(self.select_by_expr_action)
        if self.embedded_advanced_tool_button:
            self.embedded_advanced_tool_button.setDefaultAction(self.select_by_expr_action)
        update_status_message()

    def replace_default_action(self, value):
        toolbar     = self.iface.attributesToolBar()
        main_window = self.iface.mainWindow()

        for name in ("ActionSelect", "ActionSelection", "mActionDeselectAll"):
            action = main_window.findChild(QAction, name)
            if action:
                action.setVisible(not value)

        actiontable = main_window.findChild(QAction, "mActionOpenTable")
        actionform  = main_window.findChild(QAction, "mActionSelectByForm")

        toolbar.removeAction(self.embedded_selection_tool_button_action)
        toolbar.removeAction(self.embedded_advanced_tool_button_action)

        if value:
            self.embedded_selection_tool_button = QToolButton()
            self.embedded_selection_tool_button.setPopupMode(
                QToolButton.ToolButtonPopupMode.MenuButtonPopup
            )
            self.embedded_selection_tool_button.addActions(self.select_actions)
            self.embedded_selection_tool_button.setDefaultAction(self.select_actions[0])

            self.embedded_advanced_tool_button = QToolButton()
            self.embedded_advanced_tool_button.setPopupMode(
                QToolButton.ToolButtonPopupMode.MenuButtonPopup
            )
            self.embedded_advanced_tool_button.addAction(self.select_all_action)
            self.embedded_advanced_tool_button.setDefaultAction(self.select_all_action)
            self.embedded_advanced_tool_button.addAction(self.invert_all_action)
            self.embedded_advanced_tool_button.addAction(self.select_by_expr_action)
            if actionform:
                self.embedded_advanced_tool_button.addAction(actionform)

            self.embedded_selection_tool_button_action = toolbar.insertWidget(
                actiontable, self.embedded_selection_tool_button
            )
            self.embedded_advanced_tool_button_action = toolbar.insertWidget(
                actiontable, self.embedded_advanced_tool_button
            )
            toolbar.insertAction(actiontable, self.deselect_all_action)
            if self.settings.value("show_settings", True, bool):
                toolbar.insertAction(actiontable, self.settings_action)
            else:
                toolbar.removeAction(self.settings_action)
            self.toolbar.hide()
        else:
            self.embedded_selection_tool_button = None
            self.embedded_advanced_tool_button  = None
            toolbar.removeAction(self.deselect_all_action)
            toolbar.removeAction(self.settings_action)
            self.toolbar.show()


class _SelectAction:
    def __init__(self, text, **kwargs):
        self.text       = text
        self.tooltip    = "<b>{}</b>".format(text)
        self.icon       = icon_path("selectRectangle.svg")
        self.objectname = ""
        self.tool       = None
        self.__dict__.update(kwargs)
