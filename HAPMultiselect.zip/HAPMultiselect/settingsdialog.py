"""HAPMultiselect Settings Dialog"""

from collections import Counter
from pathlib import Path

from qgis.core import QgsMapLayerModel, QgsMapLayerProxyModel, QgsProject
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QSettings, Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtWidgets import QDialog
from qgis.utils import iface

from .icon_utils import icon_path
from .utils import icon_from_layer

_LayerRole   = QgsMapLayerModel.CustomRole.Layer
_LayerIdRole = QgsMapLayerModel.CustomRole.LayerId

_PLUGIN_KEY = "plugins/HAPMultiselect"


class LayerModel(QgsMapLayerProxyModel):
    """Checkable layer model for including/excluding vector layers"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFilters(QgsMapLayerProxyModel.Filter.VectorLayer)

    def name_list(self):
        return [super().data(self.index(i, 0)) for i in range(self.rowCount())]

    def non_unique_names(self):
        return [k for k, v in Counter(self.name_list()).items() if v > 1]

    def include_all(self):
        for layer in QgsProject.instance().mapLayers().values():
            layer.removeCustomProperty(f"{_PLUGIN_KEY}/excluded")
        self.dataChanged.emit(
            self.index(0, 0),
            self.index(self.rowCount(), 0),
            [Qt.ItemDataRole.CheckStateRole],
        )

    def exclude_all(self):
        for layer in QgsProject.instance().mapLayers().values():
            layer.setCustomProperty(f"{_PLUGIN_KEY}/excluded", True)
        self.dataChanged.emit(
            self.index(0, 0),
            self.index(self.rowCount(), 0),
            [Qt.ItemDataRole.CheckStateRole],
        )

    def flags(self, index):
        return (
            Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsSelectable
            | Qt.ItemFlag.ItemIsUserCheckable
        )

    def setData(self, index, value, role=Qt.ItemDataRole.DisplayRole):
        layer = super().data(index, _LayerRole)
        if not layer:
            return super().setData(index, value, role)
        if role == Qt.ItemDataRole.CheckStateRole:
            layer.setCustomProperty(
                f"{_PLUGIN_KEY}/excluded",
                value == Qt.CheckState.Unchecked,
            )
            return True
        return super().setData(index, value, role)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        layer = super().data(index, _LayerRole)
        if not layer:
            return super().data(index, role)
        if role == Qt.ItemDataRole.DisplayRole:
            original_name = super().data(index, role)
            if original_name in self.non_unique_names():
                return f"{original_name} ({super().data(index, _LayerIdRole)})"
        if role == Qt.ItemDataRole.DecorationRole:
            return icon_from_layer(layer)
        if role == Qt.ItemDataRole.CheckStateRole:
            excluded = layer.customProperty(
                f"{_PLUGIN_KEY}/excluded", False
            ) in (True, "true", "True", "1")
            return 0 if excluded else 2
        return super().data(index, role)


FORM_CLASS, _ = uic.loadUiType(Path(__file__).with_suffix(".ui"))


class SettingsDialog(QDialog, FORM_CLASS):
    settingsChanged = pyqtSignal()  # noqa: N815
    colorChanged    = pyqtSignal()  # noqa: N815

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.settings = settings
        self.setWindowIcon(QIcon(icon_path("icon.svg")))

        qs = QSettings()
        red   = qs.value("qgis/default_selection_color_red",   255, int)
        green = qs.value("qgis/default_selection_color_green", 255, int)
        blue  = qs.value("qgis/default_selection_color_blue",    0, int)
        alpha = qs.value("qgis/default_selection_color_alpha", 255, int)

        self.selectionColorButton.setDefaultColor(QColor.fromRgb(red, green, blue, alpha))
        self.selectionColorButton.setColor(iface.mapCanvas().selectionColor())

        self.onlyVisibleCheckBox.setChecked(self.settings.value("only_visible", True, bool))
        self.ignoreScaleCheckBox.setChecked(self.settings.value("ignore_scale", False, bool))
        self.activeLayerCheckBox.setChecked(self.settings.value("set_active_layer", True, bool))
        self.showSettingsCheckBox.setChecked(self.settings.value("show_settings", True, bool))
        self.replaceActionsCheckBox.setChecked(self.settings.value("replace_actions", False, bool))
        self.includeActiveLayerCheckBox.setChecked(
            self.settings.value("always_include_active_layer", True, bool)
        )

        self.layer_model = LayerModel(self)
        self.view.setModel(self.layer_model)

        self.selectionColorButton.colorChanged.connect(self.on_color_changed)
        self.onlyVisibleCheckBox.toggled.connect(self.on_only_visible_changed)
        self.ignoreScaleCheckBox.toggled.connect(self.on_ignore_scale_changed)
        self.activeLayerCheckBox.toggled.connect(self.on_active_layer_changed)
        self.showSettingsCheckBox.toggled.connect(self.on_show_settings_changed)
        self.replaceActionsCheckBox.toggled.connect(self.on_replace_actions_changed)
        self.includeActiveLayerCheckBox.toggled.connect(
            self.on_always_include_active_layer_changed
        )
        self.excludeButton.clicked.connect(self.layer_model.exclude_all)
        self.includeButton.clicked.connect(self.layer_model.include_all)

    def on_project_color_changed(self):
        try:
            self.selectionColorButton.setColor(QgsProject.instance().selectionColor())
        except AttributeError:
            self.selectionColorButton.setColor(iface.mapCanvas().selectionColor())

    def on_color_changed(self, color: QColor):
        try:
            QgsProject.instance().setSelectionColor(color)
            QgsProject.instance().setDirty()
        except AttributeError:
            iface.mapCanvas().setSelectionColor(color)
        self.colorChanged.emit()

    def on_only_visible_changed(self, checked):
        self.settings.setValue("only_visible", checked)
        self.settingsChanged.emit()

    def on_active_layer_changed(self, checked):
        self.settings.setValue("set_active_layer", checked)
        self.settingsChanged.emit()

    def on_ignore_scale_changed(self, checked):
        self.settings.setValue("ignore_scale", checked)
        self.settingsChanged.emit()

    def on_show_settings_changed(self, checked):
        self.settings.setValue("show_settings", checked)
        self.settingsChanged.emit()

    def on_replace_actions_changed(self, checked):
        self.settings.setValue("replace_actions", checked)
        self.settingsChanged.emit()

    def on_always_include_active_layer_changed(self, checked):
        self.settings.setValue("always_include_active_layer", checked)
        self.settingsChanged.emit()
