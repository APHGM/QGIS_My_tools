from .hapgo2next import HAPGo2Next


def classFactory(iface):
    return HAPGo2Next(iface)
