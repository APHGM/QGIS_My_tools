"""HAPGo2Next — navigate features in attribute order (QGIS 4 / PyQt6)"""

import os

from qgis.PyQt.QtCore import QCoreApplication, QSettings, Qt, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from . import resources  # noqa: F401 — registers the embedded icon
from .hapgo2next_dockwidget import HAPGo2NextDockWidget


class HAPGo2Next:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)

        locale = QSettings().value("locale/userLocale")[0:2]
        locale_path = os.path.join(self.plugin_dir, "i18n", f"HAPGo2Next_{locale}.qm")
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.plugin_is_active = False
        self.dockwidget = None

    def initGui(self):
        self.action = QAction(
            QIcon(":/plugins/HAPGo2Next/icon.png"),
            "HAPGo2Next",
            self.iface.mainWindow(),
        )
        self.action.setEnabled(True)
        self.action.triggered.connect(self.run)

        self.iface.pluginToolBar().addAction(self.action)
        self.iface.pluginMenu().addAction(self.action)

    def onClosePlugin(self):
        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)
        self.plugin_is_active = False

    def unload(self):
        self.iface.pluginMenu().removeAction(self.action)
        self.iface.pluginToolBar().removeAction(self.action)

    def run(self):
        if not self.plugin_is_active:
            self.plugin_is_active = True
            if self.dockwidget is None:
                self.dockwidget = HAPGo2NextDockWidget(self.iface)
                self.dockwidget.closingPlugin.connect(self.onClosePlugin)
                self.iface.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self.dockwidget)
            self.dockwidget.show()
        else:
            self.plugin_is_active = False
            self.dockwidget.hide()
