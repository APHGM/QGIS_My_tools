"""HAPGo2Next Dock Widget — QGIS 4 / PyQt6 compatible"""

import os
import operator
import webbrowser
from collections import OrderedDict
from enum import Enum

from qgis.core import (
    Qgis,
    NULL,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsPointXY,
    QgsProject,
    QgsVectorLayer,
)
from qgis.PyQt import QtGui, uic
from qgis.PyQt.QtCore import pyqtSignal, Qt
from qgis.PyQt.QtWidgets import (
    QApplication,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDockWidget,
    QFrame,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QRadioButton,
    QSizePolicy,
    QVBoxLayout,
)

from .helper import first_occurrence_index

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "hapgo2next_dockwidget.ui")
)


class ButtonType(Enum):
    NEXT     = 1
    PREVIOUS = 2
    FIRST    = 3
    LAST     = 4


class HAPGo2NextDockWidget(QDockWidget, FORM_CLASS):
    closingPlugin = pyqtSignal()
    plugin_name   = "HAPGo2Next"

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.setSizePolicy(
            QSizePolicy.Policy.MinimumExpanding,
            QSizePolicy.Policy.MinimumExpanding,
        )

        self.iface = iface

        self.feats_list           = []
        self.layer_id             = None
        self.layer                = None
        self.attribs_dict         = OrderedDict()
        self.attrib               = None
        self.feat_index           = None
        self.selected_feat_id     = None
        self.selected_feat_index  = None
        self.selected_features    = None
        self.changed_state_with_show = False

        self.fra_main.setLineWidth(3)
        fra_main_layer = QVBoxLayout(self.fra_main)
        fra_main_layer.setContentsMargins(0, 0, 0, 0)
        fra_main_layer.setSpacing(0)

        # ── frame 1: layer / order-by / state field / pan-zoom ──────────────
        self.fra_1 = QFrame(self.fra_main)
        self.fra_1.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        fra_1_layer = QFormLayout(self.fra_1)

        self.lbl_layer = QLabel("Layer:")
        self.cbo_layer = QComboBox()
        self.cbo_layer.setMinimumContentsLength(10)
        self.cbo_layer.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        fra_1_layer.addRow(self.lbl_layer, self.cbo_layer)

        self.lbl_attribute = QLabel("Order by:")
        self.cbo_order_by  = QComboBox()
        self.cbo_order_by.setMinimumContentsLength(10)
        self.cbo_order_by.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        fra_1_layer.addRow(self.lbl_attribute, self.cbo_order_by)

        self.chk_state = QCheckBox("Update state")
        self.lbl_state_field = QLabel("State Field:")
        self.cbo_state = QComboBox()
        self.cbo_state.setMinimumContentsLength(10)
        self.cbo_state.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        fra_1_layer.addRow(self.chk_state, self.cbo_state)

        self.lbl_action   = QLabel("For next feature:")
        self.fra_action   = QFrame(self.fra_1)
        fra_action_layer  = QHBoxLayout(self.fra_action)
        fra_action_layer.setContentsMargins(5, 0, 5, 0)

        self.rad_action_pan  = QRadioButton("pan")
        self.rad_action_pan.setChecked(True)
        self.rad_action_zoom = QRadioButton("pan and zoom")

        self.group_rad_action = QButtonGroup(self.fra_1)
        self.group_rad_action.addButton(self.rad_action_pan)
        self.group_rad_action.addButton(self.rad_action_zoom)

        fra_action_layer.addWidget(self.rad_action_pan)
        fra_action_layer.addWidget(self.rad_action_zoom)
        fra_1_layer.addRow(self.lbl_action, self.fra_action)

        # ── frame 2: selected-feature options / copy button ─────────────────
        self.fra_2    = QFrame(self.fra_main)
        fra_2_layer   = QGridLayout(self.fra_2)
        fra_2_layer.setContentsMargins(5, 0, 10, 0)

        self.chk_use_selected   = QCheckBox("Go to selected features")
        self.chk_start_selected = QCheckBox("Start from selected feature")
        self.chk_select         = QCheckBox("Select feature")

        fra_2_layer.addWidget(self.chk_use_selected,   0, 0)
        fra_2_layer.addWidget(self.chk_start_selected, 0, 1)
        fra_2_layer.addWidget(self.chk_select,         1, 0)

        self.btn_copy = QPushButton("Copy Feature")
        self.btn_copy.setMaximumWidth(79)
        self.btn_copy.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        fra_2_layer.addWidget(self.btn_copy, 1, 1)

        # ── frame 3: feature counter / value / OSM button ───────────────────
        self.fra_3  = QFrame(self.fra_main)
        fra_3_layer = QGridLayout(self.fra_3)

        self.lbl_feat_count1 = QLabel("Feature no.")
        fra_3_layer.addWidget(self.lbl_feat_count1, 0, 0)

        self.lbl_feat_count = QLabel("- of -")
        fra_3_layer.addWidget(self.lbl_feat_count, 0, 1)

        self.lbl_current = QLabel("Value:")
        fra_3_layer.addWidget(self.lbl_current, 1, 0)

        self.txt_value = QLineEdit()
        self.txt_value.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        self.txt_value.setReadOnly(True)
        self.txt_value.setMaximumHeight(21)
        fra_3_layer.addWidget(self.txt_value, 1, 1)

        self.btn_show_osm = QPushButton("Show on OSM")
        fra_3_layer.addWidget(self.btn_show_osm, 1, 2)

        # ── frame 4: state radio buttons ────────────────────────────────────
        self.fra_4  = QFrame(self.fra_main)
        fra_4_layer = QGridLayout(self.fra_4)

        self.lbl_state = QLabel("State:")
        fra_4_layer.addWidget(self.lbl_state, 0, 0)

        self.fra_state    = QFrame(self.fra_4)
        fra_state_layer   = QGridLayout(self.fra_state)
        fra_state_layer.setContentsMargins(50, 0, 50, 0)

        self.rad_state_undefined     = QRadioButton("undefined")
        self.rad_state_undefined.setChecked(True)
        self.rad_state_unknown       = QRadioButton("unknown")
        self.rad_state_fixed         = QRadioButton("fixed")
        self.rad_state_already_fixed = QRadioButton("already fixed")
        self.rad_state_no_issue      = QRadioButton("no issue")

        self.group_rad_state = QButtonGroup(self.fra_4)
        for btn in (
            self.rad_state_undefined,
            self.rad_state_unknown,
            self.rad_state_fixed,
            self.rad_state_already_fixed,
            self.rad_state_no_issue,
        ):
            self.group_rad_state.addButton(btn)

        fra_state_layer.addWidget(self.rad_state_fixed,         0, 0)
        fra_state_layer.addWidget(self.rad_state_already_fixed, 0, 1)
        fra_state_layer.addWidget(self.rad_state_no_issue,      1, 0)
        fra_state_layer.addWidget(self.rad_state_unknown,       1, 1)
        fra_state_layer.addWidget(self.rad_state_undefined,     2, 0)

        fra_4_layer.addWidget(self.fra_state, 1, 0)

        # ── frame 5: navigation buttons ─────────────────────────────────────
        self.fra_5  = QFrame(self.fra_main)
        fra_5_layer = QHBoxLayout(self.fra_5)
        fra_5_layer.setSpacing(0)

        self.btn_first_feature = QPushButton("<<")
        self.btn_first_feature.setMaximumWidth(45)
        self.btn_prev          = QPushButton("<")
        self.btn_next          = QPushButton(">")
        self.btn_last_feature  = QPushButton(">>")
        self.btn_last_feature.setMaximumWidth(45)

        for btn in (
            self.btn_first_feature,
            self.btn_prev,
            self.btn_next,
            self.btn_last_feature,
        ):
            fra_5_layer.addWidget(btn)

        for frame in (self.fra_1, self.fra_2, self.fra_3, self.fra_4, self.fra_5):
            fra_main_layer.addWidget(frame)

        self.states = {
            self.rad_state_undefined.text():     self.rad_state_undefined,
            self.rad_state_unknown.text():       self.rad_state_unknown,
            self.rad_state_fixed.text():         self.rad_state_fixed,
            self.rad_state_already_fixed.text(): self.rad_state_already_fixed,
            self.rad_state_no_issue.text():      self.rad_state_no_issue,
        }

        self._setup()

    # ── setup ────────────────────────────────────────────────────────────────

    def _setup(self):
        self.setWindowTitle(self.plugin_name)

        QgsProject.instance().layerWasAdded.connect(self.update_layers_combos)
        QgsProject.instance().layerRemoved.connect(self.update_layers_combos)

        self.chk_state.toggled.connect(self.chk_activate_deactivate_state)
        self.chk_use_selected.toggled.connect(self.chk_use_selected_clicked)
        self.chk_start_selected.toggled.connect(self.chk_start_selected_clicked)

        self.cbo_layer.activated.connect(self.cbo_layer_activated)
        self.cbo_order_by.activated.connect(self.cbo_order_by_activated)
        self.cbo_state.activated.connect(self.activate_state)

        self.btn_prev.pressed.connect(lambda: self.next_feat(ButtonType.PREVIOUS))
        self.btn_next.pressed.connect(lambda: self.next_feat(ButtonType.NEXT))
        self.btn_first_feature.pressed.connect(lambda: self.next_feat(ButtonType.FIRST))
        self.btn_last_feature.pressed.connect(lambda: self.next_feat(ButtonType.LAST))
        self.btn_copy.pressed.connect(self.btn_copy_pressed)
        self.btn_show_osm.pressed.connect(self.btn_show_osm_pressed)

        self.update_layers_combos()
        self.toggle_controls(False)
        self.chk_activate_deactivate_state()

        # Tooltips
        self.chk_use_selected.setToolTip("Go to selected features only")
        self.btn_copy.setToolTip("Copy feature as attribute=value pairs (Ctrl+Shift+8)")
        self.btn_show_osm.setToolTip("Show feature on OpenStreetMap")
        self.btn_first_feature.setToolTip("First feature")
        self.btn_last_feature.setToolTip("Last feature")
        self.btn_prev.setToolTip("Previous feature")
        self.btn_next.setToolTip("Next feature (F8)")

        self.btn_next.setShortcut("F8")
        self.btn_copy.setShortcut(QtGui.QKeySequence("Ctrl+Shift+8"))

        for rad, slot in (
            (self.rad_state_undefined,     self.rad_state_undefined),
            (self.rad_state_unknown,       self.rad_state_unknown),
            (self.rad_state_fixed,         self.rad_state_fixed),
            (self.rad_state_already_fixed, self.rad_state_already_fixed),
            (self.rad_state_no_issue,      self.rad_state_no_issue),
        ):
            rad.toggled.connect(lambda checked, b=rad: self.rad_btn_state(b))

    # ── Qt events ────────────────────────────────────────────────────────────

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    # ── layer combo ──────────────────────────────────────────────────────────

    def update_layers_combos(self):
        prev_layer_id = None
        if self.cbo_layer.currentIndex() is not None:
            prev_layer_id = self.cbo_layer.itemData(self.cbo_layer.currentIndex())

        layer_ids = QgsProject.instance().mapLayers()
        names_ids = {}
        for lid, layer in layer_ids.items():
            if isinstance(layer, QgsVectorLayer):
                names_ids[lid] = layer.name()

        self.cbo_layer.clear()
        self.cbo_layer.addItem("", None)
        for lid, name in sorted(names_ids.items(), key=lambda x: x[1]):
            self.cbo_layer.addItem(name, lid)

        if prev_layer_id is not None:
            self.layer_id = self._set_layercombo_index(self.cbo_layer, prev_layer_id)
        else:
            self.toggle_navigation_btn(self.btn_prev, self.layer_id is not None)
            self.toggle_navigation_btn(self.btn_next, self.layer_id is not None)
            self.cbo_layer_activated()
            self.show_feature_count()

        if self.layer_id is None:
            self.toggle_controls(False)

    def cbo_layer_activated(self):
        self.layer_id = self.cbo_layer.itemData(self.cbo_layer.currentIndex())
        self.chk_use_selected.setChecked(False)

        if self.layer_id is not None:
            self.layer = QgsProject.instance().mapLayer(self.layer_id)
            self.layer.selectionChanged.connect(self.selection_changed)

            fields = self.layer.fields()
            self.cbo_order_by.clear()
            self.cbo_state.clear()
            self.cbo_state.addItem("", None)
            pk = self.layer.primaryKeyAttributes()
            for count, field in sorted(
                enumerate(fields), key=lambda f: f[1].name().upper()
            ):
                self.attribs_dict[field.name()] = field
                self.cbo_order_by.addItem(field.name(), field)
                # string fields only, not primary key
                if field.type() == 10 and count not in pk:
                    self.cbo_state.addItem(field.name(), field)

            self.cbo_order_by_activated()
            self.layer.editingStopped.connect(self.editing_ended)
            if any(True for _ in self.layer.getFeatures()):
                self.toggle_controls(True)
            self.btn_show_osm.setEnabled(False)
            self.reload_selected_features()
        else:
            self.layer = None
            self.feats_list.clear()
            self.attrib = None
            self.attribs_dict.clear()
            self.toggle_controls(False)
            self.show_feature_count()

    def cbo_order_by_activated(self):
        if self.layer and self.cbo_order_by.currentText():
            self.feats_list = self._sort_list(self.layer.getFeatures())
        else:
            self.feats_list = []
        self.feat_index          = None
        self.selected_feat_index = None
        self.reset_navigation_buttons()
        self.show_feature_count()

    # ── selection helpers ────────────────────────────────────────────────────

    def reload_selected_features(self):
        self.selected_features = self._sort_list(self.layer.selectedFeatures())

    def selection_changed(self):
        self.reload_selected_features()
        self.chk_use_selected.setChecked(False)
        self.selected_feat_index = None

    def chk_use_selected_clicked(self):
        if self.chk_use_selected.isChecked() and len(self.selected_features) < 1:
            self.chk_use_selected.setChecked(False)
            self._warn("Please select at least one feature.")
            return
        self.feat_index          = None
        self.selected_feat_id    = None
        self.chk_start_selected.setEnabled(not self.chk_use_selected.isChecked())
        self.chk_select.setEnabled(not self.chk_use_selected.isChecked())
        self.reset_navigation_buttons()

    def chk_start_selected_clicked(self):
        if self.chk_start_selected.isChecked():
            if len(self.selected_features) != 1:
                self._warn("Please select one feature.")
                return
            self.feat_index      = None
            self.selected_feat_id = None
            self.reset_navigation_buttons()

    # ── state ────────────────────────────────────────────────────────────────

    def activate_state(self):
        result = self._should_state_be_active()
        for btn in self.states.values():
            btn.setEnabled(result)
        return result

    def _should_state_be_active(self):
        attrib = self.cbo_state.itemData(self.cbo_state.currentIndex())
        return attrib is not None and self.cbo_state.isEnabled()

    def chk_activate_deactivate_state(self):
        if self._control_is_editable():
            self.cbo_state.setEnabled(self.chk_state.isChecked())
            self.activate_state()

    def _control_is_editable(self):
        if self.layer and not self.layer.isEditable() and self.chk_state.isChecked():
            self._warn("Please set the selected layer in edit mode first.")
            self.chk_state.setChecked(False)
            return False
        return True

    def set_state(self, state_attribute):
        if not self.states[state_attribute].isChecked():
            self.changed_state_with_show = True
            self.states[state_attribute].setChecked(True)

    def edit_state(self, selected_state):
        if self.feat_index is None:
            return
        if self._control_is_editable():
            sid, _ = self._state_id_attribute()
            self.layer.changeAttributeValues(
                self.feats_list[self.feat_index].id(), {sid: selected_state}
            )
            self.feats_list[self.feat_index][sid] = selected_state

    def _state_id_attribute(self):
        attrib = self.cbo_state.itemData(self.cbo_state.currentIndex())
        sid    = first_occurrence_index(
            attrib.name(), (f.name() for f in self.layer.fields())
        )
        return sid, str(self.feats_list[self.feat_index].attributes()[sid])

    def editing_ended(self):
        self.cbo_state.setEnabled(False)
        self.cbo_state.setCurrentIndex(0)
        self.chk_state.setChecked(False)
        for btn in self.states.values():
            btn.setEnabled(False)
        self.set_state("undefined")

    def rad_btn_state(self, button):
        if button.isChecked():
            if self.changed_state_with_show:
                self.changed_state_with_show = False
            else:
                self.edit_state(NULL if button.text() == "undefined" else button.text())

    # ── navigation ───────────────────────────────────────────────────────────

    def next_feat(self, button_type):
        if self.chk_start_selected.isChecked():
            try:
                self._start_from_selected()
            except ValueError:
                return
        elif self.chk_use_selected.isChecked():
            self._go_to_next_selected_feature(button_type)
        else:
            self.feat_index = self._change_index(
                button_type, self.feat_index, self.feats_list
            )

        if self._should_state_be_active():
            if self.feat_index is None:
                return
            _, state_attr = self._state_id_attribute()
            self.set_state(
                state_attr if state_attr in self.states else "undefined"
            )

        self._focus_on_feature()
        self.show_feature_count()

    def _start_from_selected(self):
        if len(self.selected_features) != 1:
            self._warn("Please select exactly one feature.")
            raise ValueError()
        ref_id = self.selected_features[0].id()
        self.feat_index = first_occurrence_index(
            ref_id, (f.id() for f in self.feats_list)
        )
        self.chk_start_selected.setChecked(False)
        self._enable_disable_navigation(self.feat_index, self.feats_list)

    def _go_to_next_selected_feature(self, button_type):
        self.selected_feat_index = self._change_index(
            button_type, self.selected_feat_index, self.selected_features
        )
        ref_id = self.selected_features[self.selected_feat_index].id()
        self.feat_index = first_occurrence_index(
            ref_id, (f.id() for f in self.feats_list)
        )

    def _change_index(self, button_type, index, lst):
        if index is None:
            index = 0
        elif button_type == ButtonType.NEXT:
            index += 1
        elif button_type == ButtonType.PREVIOUS:
            index -= 1
        elif button_type == ButtonType.FIRST:
            index = 0
        elif button_type == ButtonType.LAST:
            index = len(lst) - 1
        self._enable_disable_navigation(index, lst)
        return index

    def _enable_disable_navigation(self, index, lst):
        has_next = index < len(lst) - 1
        self.toggle_navigation_btn(self.btn_next, has_next)
        self.toggle_navigation_btn(self.btn_last_feature, has_next)
        has_prev = index > 0
        self.toggle_navigation_btn(self.btn_prev, has_prev)
        self.toggle_navigation_btn(self.btn_first_feature, has_prev)

    # ── display / map ────────────────────────────────────────────────────────

    def _focus_on_feature(self):
        self.btn_show_osm.setEnabled(True)
        geom = self._current_feature().geometry()
        if geom is None or geom.isNull():
            self._warn("Feature geometry is null — cannot pan or zoom.")
            self.txt_value.setText("-")
        else:
            self._move_to_geometry(geom)
            self.iface.mapCanvas().refresh()
            self.txt_value.setText(
                str(self._current_feature().attribute(self.cbo_order_by.currentText()))
            )
        if self.chk_select.isChecked():
            self.layer.selectByIds([self._current_feature().id()])

    def _move_to_geometry(self, geom):
        renderer = self.iface.mapCanvas().mapSettings()
        if self.rad_action_pan.isChecked():
            self.iface.mapCanvas().setCenter(
                renderer.layerToMapCoordinates(self.layer, geom.centroid().asPoint())
            )
        else:
            bb = geom.boundingBox()
            margin = max(bb.width(), bb.height()) * 0.4
            self.iface.mapCanvas().setExtent(
                renderer.layerToMapCoordinates(self.layer, bb.buffered(margin))
            )

    def show_feature_count(self):
        total = len(self.feats_list)
        if not self.layer_id or self.feat_index is None:
            self.txt_value.setText("-")
            self.lbl_feat_count.setText(f"- of {total} features")
        else:
            self.lbl_feat_count.setText(f"{self.feat_index + 1} of {total}")

    def reset_navigation_buttons(self):
        self.toggle_navigation_btn(self.btn_prev, False)
        self.toggle_navigation_btn(self.btn_next, True)
        self.toggle_navigation_btn(self.btn_first_feature, False)
        self.toggle_navigation_btn(self.btn_last_feature, True)
        self.btn_show_osm.setEnabled(False)

    def toggle_controls(self, active):
        for w in (
            self.chk_use_selected,
            self.chk_start_selected,
            self.cbo_order_by,
            self.chk_state,
            self.chk_select,
            self.rad_action_zoom,
            self.rad_action_pan,
            self.btn_copy,
            self.btn_show_osm,
        ):
            w.setEnabled(active)
        self.toggle_navigation_btn(self.btn_prev, False)
        self.toggle_navigation_btn(self.btn_first_feature, False)
        self.chk_state.setChecked(False)
        if not self.feats_list:
            active = False
        self.toggle_navigation_btn(self.btn_next, active)
        self.toggle_navigation_btn(self.btn_last_feature, active)

    def toggle_navigation_btn(self, btn, active):
        font = QtGui.QFont()
        font.setBold(active)
        btn.setFont(font)
        btn.setEnabled(active)

    # ── button actions ───────────────────────────────────────────────────────

    def btn_copy_pressed(self):
        sel = self.layer.selectedFeatures()
        if len(sel) != 1:
            self._warn("Please select exactly one feature from the layer.")
            return
        QApplication.clipboard().setText(self._osm_field_attribute_string(sel[0]))

    def btn_show_osm_pressed(self):
        geom = self._current_feature().geometry()
        if geom is None or geom.isNull():
            self._warn("No feature/coordinates.")
            return
        crs_dest = QgsCoordinateReferenceSystem(4326)
        xform    = QgsCoordinateTransform(
            self.layer.crs(), crs_dest, QgsProject.instance()
        )
        pt  = geom.centroid().asPoint()
        pt4 = xform.transform(QgsPointXY(pt[0], pt[1]))
        lat = self._cap_coord(pt4[1])
        lon = self._cap_coord(pt4[0])
        webbrowser.open(
            f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=18/{lat}/{lon}"
        )

    # ── helpers ──────────────────────────────────────────────────────────────

    def _sort_list(self, feature_iter):
        key = self.cbo_order_by.currentText()
        if not key:
            return list(feature_iter)
        return sorted(feature_iter, key=lambda f: (f.attribute(key) is None, f.attribute(key)))

    def _current_feature(self):
        return self.feats_list[self.feat_index]

    def _set_layercombo_index(self, combo, layer_id):
        idx = combo.findData(layer_id)
        if idx >= 0:
            combo.setCurrentIndex(idx)
            lid = combo.itemData(idx)
            return QgsProject.instance().mapLayer(lid)
        if combo.count() > 0:
            combo.setCurrentIndex(0)
            return combo.itemData(0)
        return None

    @staticmethod
    def _osm_field_attribute_string(feature):
        return "\n".join(
            f"{name}={val}"
            for name, val in zip(
                (f.name() for f in feature.fields()), feature.attributes()
            )
            if name[:1] != "@" and val != NULL
        )

    @staticmethod
    def _cap_coord(coord):
        s = str(coord)
        dot = s.find(".")
        return s if dot == -1 else s[: dot + 6]

    def _warn(self, message):
        self.iface.messageBar().pushMessage(
            self.plugin_name, message, Qgis.MessageLevel.Warning
        )
